# matkinh
matkinh là trang web quản lý cửa hàng mắt kính được viết bằng PHP

## Cài đặt
- Tải [WAMP](https://www.wampserver.com/en/download-wampserver-64bits/) về máy
- Cài đặt WAMP trên máy
- Đặt cổng mặc định cho WAMP (Apache: 80, MySQL:3306)
- Cho thư mục "khang" vào "WAMP/www"
- Mở PHPMyAdmin, tạo database tên "qlkmk" và nhập file "khang/qlkmk.sql"
- Vào mục "Browse www" và chạy trang quản lý
